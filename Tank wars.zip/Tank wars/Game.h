#pragma once
#include <SFML\Graphics.hpp>

using namespace sf;
using namespace std;

class Game
{
public:
	Game();
	~Game();

	void Play();
	
};

