#include "Menu.h"
#include "Game.h"
#include<iostream>


Menu::Menu(Vector2f size, RectangleShape shape)
{
	this->gameName = "Tanks";
	this->body = shape;
}

Menu::~Menu() {}


void Menu::Display(RenderWindow& window)
{
	window.draw(body);

	/*cout << "Welcome to " << gameName << "!" << endl;
	cout << "Below are options:" << endl;
	cout << "1. play" << endl;
	cout << "2. instruction" << endl;
	cout << "3. credits" << endl;
	cout << "4. exit" << endl;*/
}

char Menu::Choose()
{
	cout << "Your choice: "; cin >> choice;
	return choice;
}

void Menu::PerformAction(char choice)
{
	switch (choice)
	{
	case '1':
	{
		Game game;
		game.Play();
		break;
	}
	case '2':
	{
		cout << "Here are instructions" << endl;
		break;
	}
	case '3':
	{
		cout << "Here are credits" << endl;
		break;
	}
	case '4':
	{
		cout << "Bye" << endl;
		break;
	}
	default:
	{
		cout << "Unknow option, please try again" << endl;
		break;
	}
	}
}
