#include "Menu.h"


using namespace std;

int main()
{
	RectangleShape surface;
	surface.setSize(Vector2f(8, 360));
	Texture menuTexture;
	menuTexture.loadFromFile("grass1.jpg");
	surface.setTexture(&menuTexture);
	surface.setPosition(550, 720);
	surface.setTextureRect(IntRect(100, 500, 8,5));
	RenderWindow window(VideoMode(1280, 720), "SFML Program", Style::Close | Style::Titlebar);
	window.setFramerateLimit(60);
	window.setMouseCursorVisible(false);
	char userChoice = '0';
	do
	{
		Menu menu(Vector2f(100, 55), surface);
		menu.Display(window);
		userChoice = menu.Choose();
		menu.PerformAction(userChoice);
	} while (userChoice != '4');


	system("pause");
	return 0;
}