#pragma once
#include <SFML\Graphics.hpp>
#include<string>

using namespace sf;
using namespace std;
class Menu
{
public:
	Menu(Vector2f size, RectangleShape texture);
	~Menu();
	char choice;
	void Display(RenderWindow& window);
	char Choose();
	void PerformAction(char choice);
	RectangleShape body;
private:
	string gameName;
	

};

